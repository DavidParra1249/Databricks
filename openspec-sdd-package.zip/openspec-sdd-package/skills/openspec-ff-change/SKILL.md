---
name: openspec-ff-change
description: Fast-forward through OpenSpec artifact creation. Use when the user wants to quickly create all artifacts needed for implementation without stepping through each one individually.
metadata:
  author: openspec
  version: "1.0"
  ported-from: skills/openspec-ff-change/SKILL.md
---

> **Databricks Genie Code port** of Fission-AI/OpenSpec.
> **Root resolution**: Find the nearest `openspec/` directory relative to the user's current project.
> **Scripts**: `.assistant/skills/openspec-sdd/scripts/` (pass `--root <project>/openspec` to all scripts).
> **Schemas**: `.assistant/skills/openspec-sdd/schemas/spec-driven/` (global, ships with the install).

Fast-forward through artifact creation - generate everything needed to start implementation in one go.

**Input**: The user's request should include a change name (kebab-case) OR a description of what they want to build.

**Steps**

1. **Resolve the project root**

   Find the nearest `openspec/` directory relative to the user's current project.
   Set `ROOT` = `<project>/openspec`, `SCRIPTS` = `.assistant/skills/openspec-sdd/scripts`, `PACKAGE` = `.assistant/skills/openspec-sdd`.

2. **If no clear input provided, ask what they want to build**

   Ask the user (open-ended, no preset options):
   > "What change do you want to work on? Describe what you want to build or fix."

   From their description, derive a kebab-case name (e.g., "add user authentication" → `add-user-auth`).

   **IMPORTANT**: Do NOT proceed without understanding what the user wants to build.

3. **Create the change directory**

   Create `<ROOT>/changes/<name>/` with `.openspec.yaml`:
   ```yaml
   schema: spec-driven
   created: YYYY-MM-DD
   ```

4. **Get the artifact build order**

   ```sh
   python <SCRIPTS>/status.py --root <ROOT> --change <name> --json
   ```
   Parse the JSON to get:
   - `artifacts`: list of all artifacts with `status` and `requires` edges
   - The dependency graph determines build order

5. **Create every artifact in the required set**

   Use a todo list to track progress through the artifacts.

   Loop through artifacts in dependency order (artifacts with no pending dependencies first):

   a. **For each artifact that is `ready` (dependencies satisfied)**:
      - Read the artifact's `instruction` and `template` from `<PACKAGE>/schemas/spec-driven/schema.yaml`
      - Read the template from `<PACKAGE>/schemas/spec-driven/templates/<artifact>.md`
      - Read any completed dependency files for context - always re-read from disk
      - **Inspect the relevant project before drafting**: Read context from `config.yaml`, then inspect relevant implementation, tests, configuration, and documentation outside `openspec/`. Keep inspection read-only and proportional to the change.
        - Ground scope, approach, and tasks in what you find. Distinguish observed behavior from assumptions.
        - Do this discovery now, rather than leaving generic "explore the codebase" tasks for implementation.
      - Create the artifact file using `template` as the structure and write it to the correct path
      - Apply `context` and `rules` as constraints - but do NOT copy them into the file
      - Show brief progress: "✓ Created <artifact-id>"

   b. **Continue until every artifact in the required set exists**
      - After creating each artifact, re-run:
        ```sh
        python <SCRIPTS>/status.py --root <ROOT> --change <name> --json
        ```
      - The required set is all artifacts reachable by following the `requires` edges transitively (spec-driven closes over proposal, specs, design, tasks)
      - An artifact already reading `status: "skipped"` is satisfied; never try to create one
      - Create every artifact in the required set that is missing, then re-check
      - Skip one only when its `instruction` in schema.yaml marks it optional (e.g., design.md is conditional). Tell the user, and do not reconsider
      - Stop when every artifact in the required set is `done`, `skipped`, or deliberately skipped

   c. **If an artifact requires user input** (unclear context):
      - Ask the user to clarify
      - Then continue with creation

6. **Show final status**

   ```sh
   python <SCRIPTS>/status.py --root <ROOT> --change <name>
   ```

**Output**

After completing all artifacts, summarize:
- Change name and location
- List of artifacts created with brief descriptions, plus any conditional artifact skipped and why
- What's ready: "All artifacts needed for implementation are ready."
- Prompt: "Run `/opsx:apply` to start working on the tasks."

**Artifact Creation Guidelines**

- Follow the `instruction` field from schema.yaml for each artifact type - it is the authoritative guidance
- The schema defines what each artifact should contain - follow it
- Read dependency artifacts for context before creating new ones
- Use `template` as the structure for your output file - fill in its sections
- **IMPORTANT**: `context` and `rules` are constraints for YOU, not content for the file
  - Do NOT copy `<context>`, `<rules>`, `<project_context>` blocks into the artifact

**Guardrails**
- Create every artifact the apply phase transitively depends on
- Always read dependency artifacts before creating a new one - re-read from disk, not from conversation memory
- If context is critically unclear, ask the user - but prefer making reasonable decisions to keep momentum
- If a change with that name already exists, suggest continuing that change instead
- Verify each artifact file exists after writing before proceeding to next
