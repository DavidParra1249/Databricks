---
name: openspec-new-change
description: Start a new OpenSpec change using the artifact workflow. Use when the user wants to create a new feature, fix, or modification with a structured step-by-step approach.
metadata:
  author: openspec
  version: "1.0"
  ported-from: skills/openspec-new-change/SKILL.md
---

> **Databricks Genie Code port** of Fission-AI/OpenSpec.
> **Root resolution**: Find the nearest `openspec/` directory relative to the user's current project.
> **Scripts**: `.assistant/skills/openspec-sdd/scripts/` (pass `--root <project>/openspec` to all scripts).
> **Schemas**: `.assistant/skills/openspec-sdd/schemas/spec-driven/` (global, ships with the install).

Start a new change using the artifact-driven approach.

**Input**: The user's request should include a change name (kebab-case) OR a description of what they want to build.

**Steps**

1. **Resolve the project root**

   Find the nearest `openspec/` directory relative to the user's current project or asset.
   If ambiguous or not found, ask which project to use.
   Set `ROOT` = `<project>/openspec` and `SCRIPTS` = `.assistant/skills/openspec-sdd/scripts`.

2. **If no clear input provided, ask what they want to build**

   Ask the user (open-ended, no preset options):
   > "What change do you want to work on? Describe what you want to build or fix."

   From their description, derive a kebab-case name (e.g., "add user authentication" → `add-user-auth`).

   **IMPORTANT**: Do NOT proceed without understanding what the user wants to build.

3. **Determine the workflow schema**

   Use the default schema (`spec-driven`) unless the user explicitly requests a different workflow.
   Read `<ROOT>/config.yaml` to confirm the schema.

   **Use a different schema only if the user mentions:**
   - A specific schema name
   - "show workflows" or "what workflows" → list available schemas from `<PACKAGE>/schemas/`

4. **Create the change directory**

   Create `<ROOT>/changes/<name>/` with `.openspec.yaml`:
   ```yaml
   schema: spec-driven
   created: YYYY-MM-DD
   ```

5. **Show the artifact status**

   Run:
   ```sh
   python <SCRIPTS>/status.py --root <ROOT> --change <name> --json
   ```

6. **Get instructions for the first artifact**

   The first artifact depends on the schema (e.g., `proposal` for spec-driven).
   Check the status output to find the first artifact with status "ready".
   Read the schema instructions from `<PACKAGE>/schemas/spec-driven/schema.yaml` for that artifact.
   Read the template from `<PACKAGE>/schemas/spec-driven/templates/<artifact>.md`.

7. **STOP and wait for user direction**

**Output**

After completing the steps, summarize:
- Change name and location
- Schema/workflow being used and its artifact sequence
- Current status (0/N artifacts complete)
- The template for the first artifact
- Prompt: "Ready to create the first artifact? Just describe what this change is about and I'll draft it, or ask me to continue."

**Guardrails**
- Do NOT create any artifacts yet - just show the instructions
- Do NOT advance beyond showing the first artifact template
- If the name is invalid (not kebab-case), ask for a valid name
- If a change with that name already exists, suggest continuing that change instead
