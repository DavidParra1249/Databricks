---
name: openspec-bulk-archive-change
description: Archive multiple completed changes at once. Use when archiving several parallel changes.
metadata:
  author: openspec
  version: "1.0"
  ported-from: skills/openspec-bulk-archive-change/SKILL.md
---

> **Databricks Genie Code port** of Fission-AI/OpenSpec.
> **Root resolution**: Find the nearest `openspec/` directory relative to the user's current project.
> **Scripts**: `.assistant/skills/openspec-sdd/scripts/` (pass `--root <project>/openspec` to all scripts).
> **Schemas**: `.assistant/skills/openspec-sdd/schemas/spec-driven/` (global, ships with the install).

Archive multiple completed changes in a single operation.

This skill allows you to batch-archive changes, handling spec conflicts intelligently by checking the workspace to determine what's actually implemented.

`<capability-path>` is the spec directory relative to `specs/` (for example, `user-auth` or `identity/user-auth`). Preserve the full path from each delta spec when resolving its main spec.

**Input**: None required (prompts for selection)

**Steps**

1. **Resolve the project root**

   Find the nearest `openspec/` directory relative to the user's current project.
   Set `ROOT` = `<project>/openspec`, `SCRIPTS` = `.assistant/skills/openspec-sdd/scripts`, `PACKAGE` = `.assistant/skills/openspec-sdd`.

2. **Get active changes**

   ```sh
   python <SCRIPTS>/list_changes.py --root <ROOT> --json
   ```

   If no active changes exist, inform user and stop.

3. **Prompt for change selection**

   Ask the user to choose changes (multi-select):
   - Show each change with its schema
   - Include an option for "All changes"
   - Allow any number of selections (1+ works, 2+ is the typical use case)

   **IMPORTANT**: Do NOT auto-select. Always let the user choose.

4. **Batch validation - gather status for all selected changes**

   For each selected change, collect:

   a. **Artifact status**:
      ```sh
      python <SCRIPTS>/status.py --root <ROOT> --change <name> --json
      ```
      - Note which artifacts are `done` vs other states

   b. **Task completion** - Read `tasks.md` from the change directory
      - Count `- [ ]` (incomplete) vs `- [x]` (complete)
      - If no tasks file exists, note as "No tasks"

   c. **Delta specs** - Check `specs/` directory in the change
      - List which capability specs exist
      - For each, extract requirement names (lines matching `### Requirement: <name>`)
      - If no specs directory or empty, perform no spec sync for that change

5. **Detect spec conflicts**

   Build a map keyed by `<capability-path>`:

   ```text
   identity/user-auth -> [change-a, change-b]  <- CONFLICT (2+ changes)
   billing/user-auth  -> [change-c]            <- OK (different full path)
   ```

   A conflict exists when 2+ selected changes have delta specs for the exact same `<capability-path>`.

6. **Resolve conflicts agentically**

   **For each conflict**, investigate the workspace:

   a. **Read the delta specs** from each conflicting change
   b. **Search the workspace** for implementation evidence (code, notebooks, tests)
   c. **Determine resolution**:
      - If only one change is actually implemented → sync that one's specs
      - If both implemented → apply in chronological order (older first, newer overwrites)
      - If neither implemented → skip spec sync, warn user
   d. **Record resolution** for each conflict with rationale

7. **Show consolidated status table**

   ```markdown
   | Change | Artifacts | Tasks | Specs | Conflicts | Status |
   |---|---|---|---|---|---|
   | schema-mgmt | Done | 5/5 | 2 delta | None | Ready |
   | project-config | Done | 3/3 | 1 delta | None | Ready |
   | add-oauth | Done | 4/4 | 1 delta | identity/user-auth (!) | Ready* |
   | add-verify | 1 left | 2/5 | None | None | Warn |
   ```

   For conflicts, show the resolution. For incomplete changes, show warnings.

8. **Confirm batch operation**

   Ask the user a single confirmation question with options:
   - "Archive all N changes"
   - "Archive only N ready changes (skip incomplete)"
   - "Cancel"

   Route on the answer:
   - "Cancel" → stop, archive nothing
   - Archive-everything → proceed with every selected change
   - Ready-only → proceed with only `Ready`/`Ready*` changes

9. **Execute archive for each confirmed change**

   Process changes in determined order (respecting conflict resolution):

   a. **Sync included delta specs**:
      - Run the `openspec-sync` workflow inline (agent-driven intelligent merge) for changes with delta specs
      - For conflicts, apply in resolved order
      - Do not delegate to a background task

   b. **Verify synced specs before archiving**:
      - Verify ADDED requirements present in main specs
      - Verify MODIFIED requirements carry scenario changes
      - Verify REMOVED requirements are gone
      - If sync failed, do not archive that change

   c. **Perform the archive**:
      ```sh
      python <SCRIPTS>/archive.py --root <ROOT> --change <name>
      ```

   d. **Track outcome** for each change:
      - Success: archived successfully
      - Failed: error during archive or spec verification
      - Skipped: user chose not to archive
      - Sync skipped: for excluded deltas, report with reason

10. **Display summary**

    ```markdown
    ## Bulk Archive Complete

    Archived N changes:
    - change-1 -> archive/2026-09-10-change-1/
    - change-2 -> archive/2026-09-10-change-2/

    Spec sync summary:
    - N delta specs synced to main specs
    - M conflicts resolved
    ```

    Report any failures and skipped changes.

**Conflict Resolution Examples**

Example 1: Only one implemented
```text
Conflict: specs/auth/spec.md touched by [add-oauth, add-jwt]
Checking add-oauth: found implementation in src/auth/oauth.py
Checking add-jwt: no JWT implementation found
Resolution: Only add-oauth is implemented. Will sync add-oauth specs only.
```

Example 2: Both implemented
```text
Conflict: specs/api/spec.md touched by [add-rest-api, add-graphql]
add-rest-api (created 2026-01-10): found src/api/rest.py
add-graphql (created 2026-01-15): found src/api/graphql.py
Resolution: Both implemented. Apply add-rest-api first, then add-graphql (chronological).
```

**Guardrails**
- Allow any number of changes (1+ is fine)
- Always prompt for selection, never auto-select
- Detect spec conflicts early and resolve by checking workspace
- When both changes are implemented, apply specs in chronological order
- Skip spec sync only when implementation is missing (warn user)
- Show clear per-change status before confirming
- Use single confirmation for entire batch
- Never archive after the user cancels
- Track and report all outcomes (success/skip/fail)
- Preserve .openspec.yaml when moving to archive
- Archive target uses current date: YYYY-MM-DD-<name>; a name already starting with YYYY-MM-DD- is used as-is
- If archive target exists, fail that change but continue with others
- Run sync inline and verify main specs before archiving
