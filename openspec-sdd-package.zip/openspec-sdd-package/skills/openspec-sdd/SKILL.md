---
name: openspec-sdd
description: |
  Spec-driven development (SDD) for AI coding assistants — Databricks port of Fission-AI/OpenSpec.
  Load this skill when the user types /opsx:propose, /opsx:explore, /opsx:apply, /opsx:update,
  /opsx:verify, /opsx:sync, /opsx:archive, /opsx:new, /opsx:continue, /opsx:ff, /opsx:onboard,
  /opsx:bulk-archive, /opsx:status, /opsx:list, /opsx:validate, or mentions
  OpenSpec, SDD, spec-driven, or change workflow. Also load when user creates, reviews, or manages
  proposal.md, design.md, tasks.md, spec.md, or .openspec.yaml artifacts.
---

# OpenSpec SDD — Databricks Genie Code Port

Databricks port of [Fission-AI/OpenSpec](https://github.com/Fission-AI/OpenSpec).
Identical structure, adapted to run on Genie Code instead of the Node.js CLI.

## Architecture (mirrors original OpenSpec)

```
Original OpenSpec                          Databricks Port
-----------------                          ---------------
skills/<cmd>/SKILL.md (per command)   -->  .assistant/skills/openspec-<cmd>/SKILL.md
schemas/spec-driven/ (in package)     -->  .assistant/skills/openspec-sdd/schemas/spec-driven/
openspec init                          -->  .assistant/skills/openspec-sdd/scripts/init.py
openspec CLI binary                   -->  .assistant/skills/openspec-sdd/scripts/*.py
openspec/specs/                       -->  openspec/specs/
openspec/changes/                     -->  openspec/changes/
openspec/config.yaml                  -->  openspec/config.yaml
```

## Command Skills (individual SKILL.md per command)

Each command is a separate skill, identical to how OpenSpec generates
per-tool command files. Load the relevant skill when the user invokes a command:

| Command | Skill to load | Original file |
|---|---|---|
| `/opsx:propose` | `openspec-propose/SKILL.md` | `skills/openspec-propose/SKILL.md` |
| `/opsx:explore` | `openspec-explore/SKILL.md` | `skills/openspec-explore/SKILL.md` |
| `/opsx:apply` | `openspec-apply/SKILL.md` | `skills/openspec-apply-change/SKILL.md` |
| `/opsx:update` | `openspec-update/SKILL.md` | `skills/openspec-update-change/SKILL.md` |
| `/opsx:verify` | `openspec-verify/SKILL.md` | `skills/openspec-verify-change/SKILL.md` |
| `/opsx:sync` | `openspec-sync/SKILL.md` | `skills/openspec-sync-specs/SKILL.md` |
| `/opsx:archive` | `openspec-archive/SKILL.md` | `skills/openspec-archive-change/SKILL.md` |
| `/opsx:new` | `openspec-new-change/SKILL.md` | `skills/openspec-new-change/SKILL.md` |
| `/opsx:continue` | `openspec-continue-change/SKILL.md` | `skills/openspec-continue-change/SKILL.md` |
| `/opsx:ff` | `openspec-ff-change/SKILL.md` | `skills/openspec-ff-change/SKILL.md` |
| `/opsx:onboard` | `openspec-onboard/SKILL.md` | `skills/openspec-onboard/SKILL.md` |
| `/opsx:bulk-archive` | `openspec-bulk-archive-change/SKILL.md` | `skills/openspec-bulk-archive-change/SKILL.md` |

## Deterministic Scripts (replace CLI binary)

Scripts at `.assistant/skills/openspec-sdd/scripts/` replace the `openspec` CLI:

| Script | Replaces | Usage |
|---|---|---|
| `status.py` | `openspec status` | `python <scripts>/status.py --root <root> --change <name> --json` |
| `validate.py` | `openspec validate` | `python <scripts>/validate.py --root <root> --json` |
| `list_changes.py` | `openspec list` | `python <scripts>/list_changes.py --root <root> --json` |
| `sync.py` | `openspec sync` | `python <scripts>/sync.py --root <root> --change <name>` |
| `archive.py` | `openspec archive` | `python <scripts>/archive.py --root <root> --change <name>` |

## Installation Model (mirrors `npm install -g` + `openspec init`)

**Global (installed once, shared across projects):**
- Scripts: `.assistant/skills/openspec-sdd/scripts/` -- the engine
- Schemas: `.assistant/skills/openspec-sdd/schemas/` -- artifact definitions + templates
- Command skills: `.assistant/skills/openspec-*/SKILL.md` -- per-command instructions

**Per-project (created by init.py for each project):**
- `<project>/openspec/config.yaml` -- project context and rules
- `<project>/openspec/specs/` -- source of truth for that project
- `<project>/openspec/changes/` -- active and archived changes

**Root resolution:** When the user invokes a command, resolve the OpenSpec root
by finding the nearest `openspec/` directory relative to the asset the user is
working on. If ambiguous or not found, ask which project to use. Pass it as
`--root <project>/openspec` to all scripts.

## CLI → Script Mapping

Every command skill references CLI calls. Here is how they translate:

| Original CLI | Databricks equivalent |
|---|---|
| `openspec init` | `python <scripts>/init.py --project <project-dir>` |
| `openspec context --json` | Read `<project>/openspec/config.yaml` directly |
| `openspec new change "<name>"` | Create `<project>/openspec/changes/<name>/` + `.openspec.yaml` |
| `openspec instructions <artifact> --change "<name>" --json` | Read `.assistant/skills/openspec-sdd/schemas/spec-driven/schema.yaml` for instructions |
| `openspec show "<spec-id>" --type spec` | Read `<project>/openspec/specs/<spec-id>/spec.md` directly |
| Store selection (`--store <id>`) | Not applicable (single workspace) |

This skill makes Genie Code behave as the OpenSpec engine: the same artifact-guided,
spec-driven development workflow from [Fission-AI/OpenSpec](https://github.com/Fission-AI/OpenSpec),
ported to run entirely within Databricks workspace using workspace files and Python scripts
instead of the Node.js CLI.

## Philosophy

```
fluid not rigid         — no phase gates, work on what makes sense
iterative not waterfall — learn as you build, refine as you go
easy not complex        — lightweight setup, minimal ceremony
brownfield-first        — works with existing codebases, not just greenfield
```

## Workspace Layout

The OpenSpec root lives at `openspec/` relative to the user's project or home directory:

```
openspec/
├── config.yaml                        # Project config (schema, context, rules)
├── specs/                             # Source of truth — current system behavior
│   └── <domain>/
│       └── spec.md
└── changes/                           # Active changes (one folder per feature/fix)
    ├── <change-name>/
    │   ├── .openspec.yaml             # Change metadata (schema, created date)
    │   ├── proposal.md
    │   ├── specs/
    │   │   └── <capability-path>/
    │   │       └── spec.md            # Delta spec
    │   ├── design.md                  # Optional
    │   └── tasks.md
    └── archive/                       # Archived (completed) changes
        └── YYYY-MM-DD-<change-name>/
```

## Scripts (deterministic engine)

Scripts live at `.assistant/skills/openspec-sdd/scripts/`. Execute them with `executeCode` (language: sh).

| Script | CLI equivalent | What it does |
|--------|---------------|-------------|
| `validate.py` | `openspec validate` | Validates specs and changes structure |
| `status.py` | `openspec status` | Computes artifact dependency graph (ready/blocked/done) |
| `sync.py` | `openspec sync` | Merges delta specs into main specs |
| `archive.py` | `openspec archive` | Moves change to archive/ with date prefix |
| `list_changes.py` | `openspec list` | Lists active changes and specs |

Usage pattern:
```sh
python /Workspace/Users/<user>/.assistant/skills/openspec-sdd/scripts/<script>.py --root /Workspace/Users/<user>/openspec [--change <name>]
```

## Command Reference

These are the commands the user types in Genie Code chat. The agent (you) executes them.

### /opsx:explore

Think through ideas before committing to a change. This is a conversation, not a generator.

**What you do:**
- Open an exploratory conversation with no artifacts created
- Read and search the codebase/workspace to answer questions
- Compare options and name tradeoffs
- Help narrow a vague idea into a concrete, buildable scope
- When insights crystallize, suggest transitioning to `/opsx:propose`

**What you do NOT do:**
- Create any change folder or artifacts
- Write or modify code

### /opsx:propose <change-name-or-description>

Create a new change and generate all planning artifacts in one step.

**Procedure:**
1. Derive a kebab-case change name from the description
2. Create `openspec/changes/<change-name>/` directory
3. Create `.openspec.yaml` with `schema: spec-driven` and `created: YYYY-MM-DD`
4. Draft `proposal.md` following the template below
5. Draft delta `specs/<capability-path>/spec.md` for each capability in the proposal
6. Draft `design.md` ONLY if conditions warrant (see template)
7. Draft `tasks.md` with implementation checklist
8. Run `status.py` to confirm all artifacts are ready
9. Report: "Ready for implementation. Run /opsx:apply."

### /opsx:apply

Implement tasks from the change's `tasks.md`.

**Procedure:**
1. Read `tasks.md` and identify unchecked tasks
2. For each task, implement it (write code, create files, edit notebooks, etc.)
3. After completing each task, update `tasks.md` marking `- [x]`
4. If the plan needs adjustment during implementation, suggest `/opsx:update`
5. When all tasks are checked, report completion

### /opsx:update

Revise a change's planning artifacts and keep them coherent.

**Procedure:**
1. Read the user's requested changes
2. Update the relevant artifacts (proposal, specs, design, tasks)
3. Ensure coherence: if proposal scope changes, update specs and tasks accordingly
4. Run `validate.py` to check structural validity

### /opsx:verify

Validate that implementation matches the specs.

**Procedure:**
1. Read the delta specs for the change
2. Read the implemented code
3. For each requirement and scenario, verify the implementation satisfies it
4. Report pass/fail for each scenario with evidence
5. If failures found, suggest specific fixes

### /opsx:sync

Merge delta specs from a change into the main specs.

**Procedure:**
1. Run `sync.py --root <root> --change <name>`
2. Report what was merged (ADDED, MODIFIED, REMOVED requirements)
3. The main specs now reflect the new behavior

### /opsx:archive

Archive a completed change.

**Procedure:**
1. Check that all tasks in `tasks.md` are complete
2. Offer to run `/opsx:sync` first if delta specs exist
3. Run `archive.py --root <root> --change <name>`
4. Report the archive location: `openspec/changes/archive/YYYY-MM-DD-<name>/`

### /opsx:status

Show the current status of a change or all changes.

**Procedure:**
1. Run `status.py --root <root> [--change <name>]`
2. Present results: which artifacts exist, their status (done/ready/blocked)

### /opsx:list

List active changes and/or specs.

**Procedure:**
1. Run `list_changes.py --root <root> [--specs]`
2. Present results in a clean table

### /opsx:validate

Validate structural correctness of specs and changes.

**Procedure:**
1. Run `validate.py --root <root> [--change <name>]`
2. Report issues found (errors, warnings) with file locations

## Artifact Templates

### .openspec.yaml

```yaml
schema: spec-driven
created: YYYY-MM-DD
```

Optional fields:
- `skip_specs: true` — when no spec-level behavior changes (pure refactor, tooling, docs)

### proposal.md

```markdown
## Why

<!-- 1-2 sentences on the problem or opportunity. What problem does this solve? Why now? -->

## What Changes

<!-- Bullet list of changes. Be specific about new capabilities, modifications, or removals.
     Mark breaking changes with **BREAKING**. -->

## Capabilities

### New Capabilities
<!-- Each becomes a new specs/<capability-path>/spec.md. Use kebab-case. -->
- `<capability-path>`: <brief description>

### Modified Capabilities
<!-- Only list if spec-level behavior changes. Use exact existing path under openspec/specs/. -->
- `<existing-capability-path>`: <what requirement is changing>

## Impact

<!-- Affected code, APIs, dependencies, systems -->
```

**Rules:**
- Keep concise (1-2 pages). Focus on "why" not "how".
- The Capabilities section is critical — it creates the contract between proposal and specs.
- Research existing specs before filling in capabilities.
- Every change must declare at least one capability OR set `skip_specs: true` in `.openspec.yaml`.

### spec.md (delta spec)

```markdown
## Purpose
<!-- New capabilities only: 50+ chars on what this capability is for. Delete for existing capabilities. -->

## ADDED Requirements

### Requirement: <name>
<requirement text using SHALL/MUST>

#### Scenario: <name>
- **WHEN** <condition>
- **THEN** <expected outcome>
```

**Delta operations (use ## headers):**
- `## ADDED Requirements` — New behavior
- `## MODIFIED Requirements` — Changed behavior. MUST include full updated content (copy entire block from main spec, then edit)
- `## REMOVED Requirements` — Deprecated. MUST include **Reason** and **Migration**
- `## RENAMED Requirements` — Name changes only, use FROM:/TO: format

**Format rules:**
- Each requirement: `### Requirement: <name>` followed by description
- Use SHALL/MUST for normative requirements (RFC 2119)
- Each scenario: `#### Scenario: <name>` with WHEN/THEN (exactly 4 hashtags!)
- Every requirement MUST have at least one scenario
- New capabilities: start with `## Purpose` section
- MODIFIED: copy ENTIRE requirement block from main spec, then edit. Partial content loses detail at archive.

**RFC 2119 Keywords:**

| Keyword | Meaning |
|---------|--------|
| MUST / SHALL | Absolute requirement. Non-negotiable. |
| SHOULD | Strong recommendation, with room for justified exception. |
| MAY | Genuinely optional. |

### design.md

```markdown
## Context

<!-- Current state and constraints. Reference proposal.md for motivation, don't restate it. -->

## Goals / Non-Goals

**Goals:**
<!-- What this design achieves -->

**Non-Goals:**
<!-- What is explicitly out of scope -->

## Decisions

<!-- Key technical choices with rationale and alternatives considered.
     Format: Decision -> Rationale -> Alternative considered -> Why rejected -->

## Risks / Trade-offs

<!-- Format: [Risk] description -> Mitigation: action
     Format: [Trade-off] description -> Mitigation: action -->
```

**When to include design.md (create ONLY if any apply):**
- Cross-cutting change (multiple services/modules) or new architectural pattern
- New external dependency or significant data model changes
- Security, performance, or migration complexity
- Ambiguity that benefits from technical decisions before coding

### tasks.md

```markdown
## 1. <Slice name>

- [ ] 1.1 <Task description>
- [ ] 1.2 <Task description>

## 2. <Slice name>

- [ ] 2.1 <Task description>
- [ ] 2.2 <Task description>
```

**Rules:**
- Group tasks by implementation slices (logical groupings)
- Number tasks hierarchically: `<slice>.<task>`
- Include validation tasks for each slice
- Each task should be a single, completable unit
- Mark completed tasks with `[x]`
- During `/opsx:apply`, update checkboxes as tasks complete

## config.yaml Reference

```yaml
schema: spec-driven

context: |
  Project: <project name>
  Tech stack: <languages, frameworks>
  <Any project-specific context the AI should know>

rules:
  proposal:
    - <Custom rule for proposals>
  specs:
    - <Custom rule for specs>
  design:
    - <Custom rule for designs>
  tasks:
    - <Custom rule for tasks>

operations:
  apply:
    guidance:
      - <Advisory instruction for apply>
  archive:
    guidance:
      - <Advisory instruction for archive>
```

**How it works:**
- `context` appears in ALL artifact drafting (injected as project background)
- `rules` appear ONLY for the matching artifact type
- `operations` are advisory instructions for apply/archive operations

## Dependency Graph (spec-driven schema)

```
             +-- specs --+
proposal ----+           +-- tasks -- apply
             +-- design -+
```

- `proposal` comes first (no dependencies)
- `specs` and `design` depend on proposal (can be created in either order)
- `tasks` depends on both specs and design
- `apply` (implementation) starts once tasks.md exists
- `design` can be skipped if conditions don't warrant it
- `specs` can be skipped if `.openspec.yaml` has `skip_specs: true`

## Archive and Sync

**Sync** merges delta specs into main specs:
- `ADDED Requirements` are appended to the main spec
- `MODIFIED Requirements` replace matching requirements (matched by header text, whitespace-insensitive)
- `REMOVED Requirements` delete matching requirements from main spec
- New capability specs: a new `openspec/specs/<path>/spec.md` is created with the delta content

**Archive** moves the change folder:
1. Sync delta specs (if not already synced)
2. Move `openspec/changes/<name>/` to `openspec/changes/archive/YYYY-MM-DD-<name>/`
3. The main specs now reflect the completed work

## Brownfield Approach

You do NOT document the whole codebase to start. Write specs only for what you're about to change.
- First change documents the slice it touches
- Next change documents its slice
- Over time, specs fill in naturally around the work you actually do
- Delta-first: specify what's CHANGING relative to current behavior, not the entire system

## Review Checklist

After `/opsx:propose`, before `/opsx:apply`, review in this order:

1. **proposal.md** — Is this the right problem? Does scope match intent? Anything sneaking in?
2. **specs/*/spec.md** — Is "done" defined correctly? Are scenarios testable? Missing edge cases?
3. **design.md** — Does the approach make sense? Are decisions well-reasoned?
4. **tasks.md** — Is the work broken down sensibly? Missing validation steps?

The first review saves the most time. Catching a wrong turn in a proposal is nearly free;
catching it in 300 lines of code is not.

## Error Handling

- If `validate.py` reports errors, fix them before proceeding
- If a change has zero capabilities and no `skip_specs: true`, reject it
- If MODIFIED delta has partial content, warn: "Partial MODIFIED content loses detail at archive"
- If scenario uses 3 hashtags instead of 4, fix to `####`
- If requirement lacks scenarios, add at least one