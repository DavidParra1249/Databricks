#!/usr/bin/env python3
"""OpenSpec status — Databricks port of `openspec status`.

Computes artifact dependency graph for spec-driven schema.
Reports ready/blocked/done status for each artifact in a change.

Usage:
    python status.py --root /Workspace/Users/.../openspec [--change <name>] [--all] [--json]
"""
import argparse
import json
import os
import re
import sys
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict
import yaml


# Dependency graph for spec-driven schema:
#              +-- specs --+
# proposal ----+           +-- tasks -- apply
#              +-- design -+
DEPENDENCIES = {
    "proposal": [],
    "specs": ["proposal"],
    "design": ["proposal"],
    "tasks": ["specs", "design"],
}

ARTIFACT_PATHS = {
    "proposal": "proposal.md",
    "specs": "specs/",
    "design": "design.md",
    "tasks": "tasks.md",
}


@dataclass
class ArtifactStatus:
    artifact_id: str
    output_path: str
    status: str  # done | ready | blocked | skipped
    requires: List[str]
    missing_deps: Optional[List[str]] = None


@dataclass
class ChangeStatus:
    change_name: str
    schema_name: str
    change_root: str
    is_planning_complete: bool
    artifacts: List[ArtifactStatus]
    completed_tasks: int = 0
    total_tasks: int = 0
    next_steps: List[str] = field(default_factory=list)


def count_tasks(change_dir: Path) -> tuple:
    """Count completed and total tasks in tasks.md."""
    tasks_path = change_dir / "tasks.md"
    if not tasks_path.exists():
        return 0, 0
    content = tasks_path.read_text(encoding="utf-8")
    total = len(re.findall(r'^\s*-\s+\[[ x]\]', content, re.MULTILINE))
    completed = len(re.findall(r'^\s*-\s+\[x\]', content, re.MULTILINE))
    return completed, total


def artifact_exists(change_dir: Path, artifact_id: str) -> bool:
    """Check if an artifact exists."""
    path_pattern = ARTIFACT_PATHS[artifact_id]
    full_path = change_dir / path_pattern
    if path_pattern.endswith("/"):
        # Directory: check if it contains any spec.md files
        return full_path.exists() and any(full_path.rglob("spec.md"))
    return full_path.exists()


def compute_status(change_dir: Path) -> ChangeStatus:
    """Compute artifact status for a change."""
    name = change_dir.name

    # Read .openspec.yaml
    yaml_path = change_dir / ".openspec.yaml"
    schema_name = "spec-driven"
    skip_specs = False
    if yaml_path.exists():
        try:
            with open(yaml_path) as f:
                meta = yaml.safe_load(f) or {}
            schema_name = meta.get("schema", "spec-driven")
            skip_specs = meta.get("skip_specs", False)
        except Exception:
            pass

    artifacts = []
    done_set = set()

    # Compute status for each artifact in dependency order
    for art_id in ["proposal", "specs", "design", "tasks"]:
        deps = DEPENDENCIES[art_id]
        exists = artifact_exists(change_dir, art_id)

        # Handle skippable artifacts
        if art_id == "specs" and skip_specs:
            status = "skipped"
            done_set.add(art_id)
        elif art_id == "design" and not exists:
            # Design is optional; if not present, check if tasks exist
            # (which means design was intentionally skipped)
            tasks_exist = artifact_exists(change_dir, "tasks")
            if tasks_exist:
                status = "skipped"
                done_set.add(art_id)
            else:
                # Could be ready or blocked depending on deps
                missing = [d for d in deps if d not in done_set]
                if missing:
                    status = "blocked"
                else:
                    status = "ready"
        elif exists:
            status = "done"
            done_set.add(art_id)
        else:
            missing = [d for d in deps if d not in done_set]
            if missing:
                status = "blocked"
            else:
                status = "ready"

        art_status = ArtifactStatus(
            artifact_id=art_id,
            output_path=ARTIFACT_PATHS[art_id],
            status=status,
            requires=deps,
            missing_deps=[d for d in deps if d not in done_set] if status == "blocked" else None,
        )
        artifacts.append(art_status)

    is_planning_complete = all(
        a.status in ("done", "skipped") for a in artifacts
    )

    completed_tasks, total_tasks = count_tasks(change_dir)

    # Compute next steps
    next_steps = []
    ready_arts = [a for a in artifacts if a.status == "ready"]
    if ready_arts:
        next_steps.append(f"Draft: {', '.join(a.artifact_id for a in ready_arts)}")
    elif is_planning_complete and total_tasks > 0 and completed_tasks < total_tasks:
        next_steps.append(f"Run /opsx:apply ({completed_tasks}/{total_tasks} tasks done)")
    elif is_planning_complete and total_tasks > 0 and completed_tasks == total_tasks:
        next_steps.append("All tasks complete. Run /opsx:sync then /opsx:archive")
    elif not is_planning_complete:
        blocked = [a for a in artifacts if a.status == "blocked"]
        if blocked:
            next_steps.append(f"Blocked: {', '.join(a.artifact_id for a in blocked)} (need: {', '.join(set(d for a in blocked for d in (a.missing_deps or [])))})")

    return ChangeStatus(
        change_name=name,
        schema_name=schema_name,
        change_root=str(change_dir),
        is_planning_complete=is_planning_complete,
        artifacts=artifacts,
        completed_tasks=completed_tasks,
        total_tasks=total_tasks,
        next_steps=next_steps,
    )


def main():
    parser = argparse.ArgumentParser(description="OpenSpec status")
    parser.add_argument("--root", required=True, help="Path to openspec/ directory")
    parser.add_argument("--change", default=None, help="Show status for specific change")
    parser.add_argument("--all", action="store_true", help="Show all changes")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    args = parser.parse_args()

    root = Path(args.root)
    changes_dir = root / "changes"

    if not root.exists():
        print(f"ERROR: Root not found: {root}", file=sys.stderr)
        sys.exit(1)

    statuses = []

    if args.change:
        change_dir = changes_dir / args.change
        if not change_dir.exists():
            print(f"ERROR: Change '{args.change}' not found", file=sys.stderr)
            sys.exit(1)
        statuses.append(compute_status(change_dir))
    elif changes_dir.exists():
        for d in sorted(changes_dir.iterdir()):
            if d.is_dir() and d.name != "archive":
                statuses.append(compute_status(d))

    if not statuses:
        if args.json:
            print(json.dumps({"changes": [], "message": "No active changes"}))
        else:
            print("No active changes found.")
        return

    if args.json:
        output = {
            "changes": [asdict(s) for s in statuses],
            "root": str(root),
        }
        print(json.dumps(output, indent=2))
    else:
        for s in statuses:
            print(f"\n{'='*60}")
            print(f"Change: {s.change_name} (schema: {s.schema_name})")
            print(f"Planning complete: {'Yes' if s.is_planning_complete else 'No'}")
            if s.total_tasks > 0:
                print(f"Tasks: {s.completed_tasks}/{s.total_tasks}")
            print(f"{'---':60}")
            for a in s.artifacts:
                icon = {"done": "\u2713", "ready": "\u25cb", "blocked": "\u2717", "skipped": "\u2013"}[a.status]
                deps_str = ""
                if a.missing_deps:
                    deps_str = f" (needs: {', '.join(a.missing_deps)})"
                print(f"  {icon} {a.artifact_id:12s} {a.status:8s} {deps_str}")
            if s.next_steps:
                print(f"\nNext: {'; '.join(s.next_steps)}")


if __name__ == "__main__":
    main()
