#!/usr/bin/env python3
"""OpenSpec sync — Databricks port of `openspec sync` / `/opsx:sync`.

Merges delta specs from a change into the main openspec/specs/ directory.
Handles ADDED, MODIFIED, REMOVED, and RENAMED requirement sections.

Usage:
    python sync.py --root /Workspace/Users/.../openspec --change <name> [--dry-run] [--json]
"""
import argparse
import json
import os
import re
import sys
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import List, Optional


@dataclass
class SyncAction:
    operation: str  # added | modified | removed | renamed | created
    capability: str
    requirement: Optional[str] = None
    detail: Optional[str] = None


@dataclass
class SyncResult:
    change_name: str
    actions: List[SyncAction] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


REQUIREMENT_BLOCK = re.compile(
    r'(###\s+Requirement:\s+.+?)(?=\n###\s+Requirement:|\n##\s+|\Z)',
    re.DOTALL
)
REQUIREMENT_NAME = re.compile(r'###\s+Requirement:\s+(.+)')
DELTA_SECTION = re.compile(r'^##\s+(ADDED|MODIFIED|REMOVED|RENAMED)\s+Requirements', re.MULTILINE)
PURPOSE_SECTION = re.compile(r'^##\s+Purpose\s*\n(.*?)(?=\n##\s+|\Z)', re.DOTALL | re.MULTILINE)
REQUIREMENTS_HEADER = re.compile(r'^##\s+Requirements', re.MULTILINE)


def normalize_name(name: str) -> str:
    """Normalize requirement name for matching (whitespace-insensitive)."""
    return re.sub(r'\s+', ' ', name.strip())


def extract_requirements(content: str) -> dict:
    """Extract requirement blocks keyed by normalized name."""
    reqs = {}
    for match in REQUIREMENT_BLOCK.finditer(content):
        block = match.group(1).strip()
        name_match = REQUIREMENT_NAME.match(block)
        if name_match:
            name = normalize_name(name_match.group(1))
            reqs[name] = block
    return reqs


def parse_delta_sections(content: str) -> dict:
    """Parse delta spec into sections: {operation: content}."""
    sections = {}
    matches = list(DELTA_SECTION.finditer(content))
    for i, match in enumerate(matches):
        op = match.group(1).upper()
        start = match.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(content)
        sections[op] = content[start:end].strip()
    return sections


def sync_capability(delta_path: Path, main_spec_path: Path, result: SyncResult):
    """Sync one delta spec into its main spec."""
    delta_content = delta_path.read_text(encoding="utf-8")
    capability = str(delta_path.parent.relative_to(delta_path.parents[2] / "specs"))
    is_new = not main_spec_path.exists()

    if is_new:
        # New capability: create main spec from delta
        purpose_match = PURPOSE_SECTION.search(delta_content)
        purpose = purpose_match.group(1).strip() if purpose_match else "TBD \u2014 Update Purpose after archive"

        # Extract all requirements from ADDED section
        sections = parse_delta_sections(delta_content)
        added_content = sections.get("ADDED", "")
        reqs = extract_requirements(added_content)

        # Build new main spec
        lines = [f"# {capability.replace('/', ' / ').title()} Specification\n"]
        lines.append(f"## Purpose\n{purpose}\n")
        lines.append("## Requirements\n")
        for name, block in reqs.items():
            lines.append(f"{block}\n")
            result.actions.append(SyncAction("created", capability, name))

        main_spec_path.parent.mkdir(parents=True, exist_ok=True)
        main_spec_path.write_text("\n".join(lines), encoding="utf-8")
        result.actions.append(SyncAction("created", capability, detail="New capability spec created"))
        return

    # Existing capability: merge delta into main spec
    main_content = main_spec_path.read_text(encoding="utf-8")
    main_reqs = extract_requirements(main_content)
    sections = parse_delta_sections(delta_content)

    # Process ADDED
    if "ADDED" in sections:
        added_reqs = extract_requirements(sections["ADDED"])
        for name, block in added_reqs.items():
            if name in main_reqs:
                result.errors.append(f"ADDED requirement '{name}' already exists in {capability}")
                continue
            main_content = main_content.rstrip() + f"\n\n{block}\n"
            result.actions.append(SyncAction("added", capability, name))

    # Process MODIFIED
    if "MODIFIED" in sections:
        mod_reqs = extract_requirements(sections["MODIFIED"])
        for name, new_block in mod_reqs.items():
            if name not in main_reqs:
                result.errors.append(f"MODIFIED requirement '{name}' not found in {capability}")
                continue
            old_block = main_reqs[name]
            main_content = main_content.replace(old_block, new_block)
            result.actions.append(SyncAction("modified", capability, name))

    # Process REMOVED
    if "REMOVED" in sections:
        removed_reqs = extract_requirements(sections["REMOVED"])
        for name, block in removed_reqs.items():
            if name not in main_reqs:
                result.errors.append(f"REMOVED requirement '{name}' not found in {capability}")
                continue
            # Remove the requirement block from main content
            main_content = main_content.replace(main_reqs[name], "")
            # Clean up double blank lines
            main_content = re.sub(r'\n{3,}', '\n\n', main_content)
            result.actions.append(SyncAction("removed", capability, name))

    # Process RENAMED
    if "RENAMED" in sections:
        rename_content = sections["RENAMED"]
        renames = re.findall(r'FROM:\s*(.+?)\s*TO:\s*(.+)', rename_content)
        for old_name, new_name in renames:
            old_norm = normalize_name(old_name)
            if old_norm not in main_reqs:
                result.errors.append(f"RENAMED requirement '{old_name}' not found in {capability}")
                continue
            old_block = main_reqs[old_norm]
            new_block = old_block.replace(f"Requirement: {old_name.strip()}", f"Requirement: {new_name.strip()}")
            main_content = main_content.replace(old_block, new_block)
            result.actions.append(SyncAction("renamed", capability, detail=f"{old_name} -> {new_name}"))

    main_spec_path.write_text(main_content, encoding="utf-8")


def sync_change(root: Path, change_name: str, dry_run: bool = False) -> SyncResult:
    """Sync all delta specs from a change."""
    result = SyncResult(change_name=change_name)
    change_dir = root / "changes" / change_name
    delta_specs_dir = change_dir / "specs"

    if not change_dir.exists():
        result.errors.append(f"Change '{change_name}' not found")
        return result

    if not delta_specs_dir.exists():
        result.errors.append("No specs/ directory in change (nothing to sync)")
        return result

    delta_files = list(delta_specs_dir.rglob("spec.md"))
    if not delta_files:
        result.errors.append("No delta spec files found")
        return result

    for delta_path in sorted(delta_files):
        capability_path = delta_path.relative_to(delta_specs_dir).parent
        main_spec_path = root / "specs" / capability_path / "spec.md"

        if dry_run:
            delta_content = delta_path.read_text(encoding="utf-8")
            sections = parse_delta_sections(delta_content)
            for op, content in sections.items():
                reqs = extract_requirements(content)
                for name in reqs:
                    result.actions.append(SyncAction(op.lower(), str(capability_path), name, "dry-run"))
        else:
            sync_capability(delta_path, main_spec_path, result)

    return result


def main():
    parser = argparse.ArgumentParser(description="OpenSpec sync")
    parser.add_argument("--root", required=True, help="Path to openspec/ directory")
    parser.add_argument("--change", required=True, help="Change to sync")
    parser.add_argument("--dry-run", action="store_true", help="Preview without writing")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    args = parser.parse_args()

    root = Path(args.root)
    result = sync_change(root, args.change, args.dry_run)

    if args.json:
        print(json.dumps(asdict(result), indent=2))
    else:
        if result.errors:
            for e in result.errors:
                print(f"ERROR: {e}", file=sys.stderr)
        if result.actions:
            print(f"\nSync: {result.change_name}")
            for a in result.actions:
                detail = f" ({a.detail})" if a.detail else ""
                req = f" / {a.requirement}" if a.requirement else ""
                print(f"  {a.operation.upper():10s} {a.capability}{req}{detail}")
        else:
            print("No sync actions performed.")

        print(f"\nTotal: {len(result.actions)} actions, {len(result.errors)} errors")

    sys.exit(1 if result.errors else 0)


if __name__ == "__main__":
    main()
