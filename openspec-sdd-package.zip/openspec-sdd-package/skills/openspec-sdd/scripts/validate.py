#!/usr/bin/env python3
"""OpenSpec validator — Databricks port of `openspec validate`.

Validates structural correctness of specs and changes against the spec-driven schema.
Checks: artifact presence, .openspec.yaml, RFC 2119 keywords, scenario format,
requirement completeness, delta operation headers, and Purpose section.

Usage:
    python validate.py --root /Workspace/Users/.../openspec [--change <name>] [--strict]
"""
import argparse
import json
import os
import re
import sys
import yaml
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import List, Optional


@dataclass
class Issue:
    severity: str  # error | warning | info
    path: str
    message: str
    line: Optional[int] = None

    def __str__(self):
        loc = f":{self.line}" if self.line else ""
        return f"[{self.severity.upper()}] {self.path}{loc}: {self.message}"


@dataclass
class ValidationResult:
    item_id: str
    item_type: str  # change | spec
    valid: bool = True
    issues: List[Issue] = field(default_factory=list)

    def add(self, severity: str, path: str, message: str, line: Optional[int] = None):
        self.issues.append(Issue(severity, path, message, line))
        if severity == "error":
            self.valid = False


RFC2119_KEYWORDS = re.compile(r'\b(SHALL|MUST|SHOULD|MAY)\b')
REQUIREMENT_HEADER = re.compile(r'^###\s+Requirement:\s+(.+)', re.MULTILINE)
SCENARIO_HEADER = re.compile(r'^####\s+Scenario:\s+(.+)', re.MULTILINE)
BAD_SCENARIO_HEADER = re.compile(r'^###\s+Scenario:\s+', re.MULTILINE)
DELTA_SECTIONS = re.compile(r'^##\s+(ADDED|MODIFIED|REMOVED|RENAMED)\s+Requirements', re.MULTILINE)
PURPOSE_SECTION = re.compile(r'^##\s+Purpose', re.MULTILINE)
WHEN_THEN = re.compile(r'-\s+\*\*(?:WHEN|THEN)\*\*', re.MULTILINE)


def validate_openspec_yaml(change_dir: Path, result: ValidationResult):
    """Validate .openspec.yaml presence and content."""
    yaml_path = change_dir / ".openspec.yaml"
    rel = str(yaml_path)
    if not yaml_path.exists():
        result.add("error", rel, "Missing .openspec.yaml")
        return None
    try:
        with open(yaml_path) as f:
            data = yaml.safe_load(f)
        if not isinstance(data, dict):
            result.add("error", rel, ".openspec.yaml is not a valid YAML mapping")
            return None
        if "schema" not in data:
            result.add("warning", rel, "Missing 'schema' field")
        if "created" not in data:
            result.add("warning", rel, "Missing 'created' field")
        return data
    except yaml.YAMLError as e:
        result.add("error", rel, f"YAML parse error: {e}")
        return None


def validate_proposal(change_dir: Path, result: ValidationResult):
    """Validate proposal.md structure."""
    path = change_dir / "proposal.md"
    rel = str(path)
    if not path.exists():
        result.add("error", rel, "Missing proposal.md")
        return
    content = path.read_text(encoding="utf-8")
    lines = content.splitlines()

    # Check required sections
    has_why = any(re.match(r'^##\s+Why', l) for l in lines)
    has_what = any(re.match(r'^##\s+What\s+Changes', l) for l in lines)
    has_caps = any(re.match(r'^##\s+Capabilities', l) for l in lines)
    has_impact = any(re.match(r'^##\s+Impact', l) for l in lines)

    if not has_why:
        result.add("warning", rel, "Missing '## Why' section")
    if not has_what:
        result.add("warning", rel, "Missing '## What Changes' section")
    if not has_caps:
        result.add("error", rel, "Missing '## Capabilities' section")
    if not has_impact:
        result.add("info", rel, "Missing '## Impact' section")


def validate_delta_spec(spec_path: Path, result: ValidationResult, is_new_capability: bool, strict: bool = False):
    """Validate a delta spec file."""
    rel = str(spec_path)
    if not spec_path.exists():
        result.add("error", rel, "Delta spec file referenced but not found")
        return
    content = spec_path.read_text(encoding="utf-8")
    lines = content.splitlines()

    # Check for delta operation sections
    delta_ops = DELTA_SECTIONS.findall(content)
    if not delta_ops:
        result.add("error", rel, "No delta operation sections found (ADDED/MODIFIED/REMOVED/RENAMED Requirements)")

    # Check Purpose section for new capabilities
    has_purpose = PURPOSE_SECTION.search(content)
    if is_new_capability and not has_purpose:
        result.add("warning", rel, "New capability missing '## Purpose' section")
    if strict and is_new_capability and has_purpose:
        # Check purpose length
        purpose_match = PURPOSE_SECTION.search(content)
        if purpose_match:
            start = purpose_match.end()
            next_section = re.search(r'^##\s+', content[start:], re.MULTILINE)
            purpose_text = content[start:start + next_section.start()].strip() if next_section else content[start:].strip()
            if len(purpose_text) < 50:
                result.add("warning", rel, f"Purpose section too brief ({len(purpose_text)} chars, recommend 50+)")

    # Check requirements and scenarios
    requirements = REQUIREMENT_HEADER.findall(content)
    scenarios = SCENARIO_HEADER.findall(content)
    bad_scenarios = BAD_SCENARIO_HEADER.findall(content)

    if not requirements and delta_ops:
        result.add("warning", rel, "Delta sections declared but no requirements found")

    if bad_scenarios:
        for i, line in enumerate(lines, 1):
            if BAD_SCENARIO_HEADER.match(line):
                result.add("error", rel, "Scenario uses ### (3 hashtags) instead of #### (4 hashtags)", line=i)

    # Check each requirement has at least one scenario
    req_positions = [(m.start(), m.group(1)) for m in REQUIREMENT_HEADER.finditer(content)]
    scen_positions = [m.start() for m in SCENARIO_HEADER.finditer(content)]

    for i, (req_pos, req_name) in enumerate(req_positions):
        next_req_pos = req_positions[i + 1][0] if i + 1 < len(req_positions) else len(content)
        has_scenario = any(req_pos < sp < next_req_pos for sp in scen_positions)
        if not has_scenario:
            result.add("error", rel, f"Requirement '{req_name}' has no scenarios")

    # Check WHEN/THEN in scenarios
    for i, line in enumerate(lines, 1):
        if SCENARIO_HEADER.match(line):
            # Look ahead for WHEN/THEN in the next few lines
            block = "\n".join(lines[i:min(i + 10, len(lines))])
            if not re.search(r'\*\*WHEN\*\*', block):
                result.add("warning", rel, f"Scenario at line {i} missing WHEN clause", line=i)
            if not re.search(r'\*\*THEN\*\*', block):
                result.add("warning", rel, f"Scenario at line {i} missing THEN clause", line=i)

    # Check RFC 2119 keywords in requirements
    if requirements and not RFC2119_KEYWORDS.search(content):
        result.add("warning", rel, "No RFC 2119 keywords (SHALL/MUST/SHOULD/MAY) found in requirements")


def validate_design(change_dir: Path, result: ValidationResult):
    """Validate design.md structure (if present)."""
    path = change_dir / "design.md"
    if not path.exists():
        result.add("info", str(path), "No design.md (optional for simple changes)")
        return
    content = path.read_text(encoding="utf-8")
    lines = content.splitlines()

    has_context = any(re.match(r'^##\s+Context', l) for l in lines)
    has_goals = any(re.match(r'^##\s+Goals', l) for l in lines)
    has_decisions = any(re.match(r'^##\s+Decisions', l) for l in lines)
    has_risks = any(re.match(r'^##\s+Risks', l) for l in lines)

    if not has_context:
        result.add("warning", str(path), "Missing '## Context' section")
    if not has_decisions:
        result.add("warning", str(path), "Missing '## Decisions' section")


def validate_tasks(change_dir: Path, result: ValidationResult):
    """Validate tasks.md structure."""
    path = change_dir / "tasks.md"
    rel = str(path)
    if not path.exists():
        result.add("error", rel, "Missing tasks.md")
        return
    content = path.read_text(encoding="utf-8")

    # Check for task checkboxes
    tasks = re.findall(r'^\s*-\s+\[[ x]\]', content, re.MULTILINE)
    if not tasks:
        result.add("warning", rel, "No task checkboxes found (expected - [ ] or - [x] format)")

    # Check for numbered sections
    sections = re.findall(r'^##\s+\d+\.', content, re.MULTILINE)
    if not sections:
        result.add("info", rel, "Tasks not grouped by numbered slices (recommended)")


def validate_main_spec(spec_path: Path, result: ValidationResult, strict: bool = False):
    """Validate a main spec file in openspec/specs/."""
    content = spec_path.read_text(encoding="utf-8")
    rel = str(spec_path)

    has_purpose = PURPOSE_SECTION.search(content)
    if not has_purpose:
        result.add("warning", rel, "Missing '## Purpose' section")

    requirements = REQUIREMENT_HEADER.findall(content)
    if not requirements:
        result.add("warning", rel, "No requirements found")
        return

    # Check scenarios for each requirement
    req_positions = [(m.start(), m.group(1)) for m in REQUIREMENT_HEADER.finditer(content)]
    scen_positions = [m.start() for m in SCENARIO_HEADER.finditer(content)]

    for i, (req_pos, req_name) in enumerate(req_positions):
        next_req_pos = req_positions[i + 1][0] if i + 1 < len(req_positions) else len(content)
        has_scenario = any(req_pos < sp < next_req_pos for sp in scen_positions)
        if not has_scenario:
            result.add("warning", rel, f"Requirement '{req_name}' has no scenarios")


def validate_change(change_dir: Path, strict: bool = False) -> ValidationResult:
    """Validate a complete change."""
    name = change_dir.name
    result = ValidationResult(item_id=name, item_type="change")

    # Validate .openspec.yaml
    meta = validate_openspec_yaml(change_dir, result)
    skip_specs = meta.get("skip_specs", False) if meta else False

    # Validate proposal
    validate_proposal(change_dir, result)

    # Validate delta specs
    specs_dir = change_dir / "specs"
    if specs_dir.exists():
        spec_files = list(specs_dir.rglob("spec.md"))
        if not spec_files and not skip_specs:
            result.add("error", str(specs_dir), "specs/ directory exists but contains no spec.md files")
        for sf in spec_files:
            # Determine if new capability (check if main spec exists)
            rel_to_specs = sf.relative_to(specs_dir)
            capability_path = str(rel_to_specs.parent)
            validate_delta_spec(sf, result, is_new_capability=True, strict=strict)
    elif not skip_specs:
        result.add("error", str(change_dir / "specs"), "Missing specs/ directory (set skip_specs: true if no behavior changes)")

    # Validate design (optional)
    validate_design(change_dir, result)

    # Validate tasks
    validate_tasks(change_dir, result)

    return result


def validate_all(root: Path, change_name: Optional[str] = None, strict: bool = False) -> dict:
    """Validate changes and specs."""
    results = []

    changes_dir = root / "changes"
    specs_dir = root / "specs"

    # Validate changes
    if change_name:
        change_dir = changes_dir / change_name
        if change_dir.exists() and change_dir.is_dir():
            results.append(validate_change(change_dir, strict))
        else:
            r = ValidationResult(item_id=change_name, item_type="change", valid=False)
            r.add("error", str(change_dir), f"Change '{change_name}' not found")
            results.append(r)
    elif changes_dir.exists():
        for d in sorted(changes_dir.iterdir()):
            if d.is_dir() and d.name != "archive":
                results.append(validate_change(d, strict))

    # Validate main specs
    if specs_dir.exists():
        for spec_file in sorted(specs_dir.rglob("spec.md")):
            r = ValidationResult(
                item_id=str(spec_file.relative_to(specs_dir).parent),
                item_type="spec"
            )
            validate_main_spec(spec_file, r, strict)
            results.append(r)

    # Summary
    total = len(results)
    passed = sum(1 for r in results if r.valid)
    failed = total - passed

    return {
        "items": [asdict(r) for r in results],
        "summary": {"total": total, "passed": passed, "failed": failed},
        "root": str(root),
    }


def main():
    parser = argparse.ArgumentParser(description="OpenSpec validator")
    parser.add_argument("--root", required=True, help="Path to openspec/ directory")
    parser.add_argument("--change", default=None, help="Validate a specific change")
    parser.add_argument("--strict", action="store_true", help="Enable strict checks")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    args = parser.parse_args()

    root = Path(args.root)
    if not root.exists():
        print(f"ERROR: Root path not found: {root}", file=sys.stderr)
        sys.exit(1)

    result = validate_all(root, args.change, args.strict)

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        for item in result["items"]:
            status = "PASS" if item["valid"] else "FAIL"
            print(f"\n{status} {item['item_type']}: {item['item_id']}")
            for issue in item["issues"]:
                loc = f":{issue['line']}" if issue.get("line") else ""
                print(f"  [{issue['severity'].upper()}] {issue['path']}{loc}: {issue['message']}")

        s = result["summary"]
        print(f"\n{'='*60}")
        print(f"Total: {s['total']} | Passed: {s['passed']} | Failed: {s['failed']}")

    sys.exit(0 if result["summary"]["failed"] == 0 else 1)


if __name__ == "__main__":
    main()
