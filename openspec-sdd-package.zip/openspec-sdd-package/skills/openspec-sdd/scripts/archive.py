#!/usr/bin/env python3
"""OpenSpec archive — Databricks port of `openspec archive` / `/opsx:archive`.

Archives a completed change:
1. Optionally syncs delta specs into main specs
2. Moves change folder to openspec/changes/archive/YYYY-MM-DD-<name>/

Usage:
    python archive.py --root /Workspace/Users/.../openspec --change <name> [--sync] [--json]
"""
import argparse
import json
import os
import re
import shutil
import sys
from datetime import date
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import List, Optional


@dataclass
class ArchiveResult:
    change_name: str
    archive_path: Optional[str] = None
    synced: bool = False
    sync_actions: int = 0
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


def check_tasks_complete(change_dir: Path) -> tuple:
    """Check if all tasks are complete. Returns (all_done, completed, total)."""
    tasks_path = change_dir / "tasks.md"
    if not tasks_path.exists():
        return True, 0, 0  # No tasks = nothing to complete
    content = tasks_path.read_text(encoding="utf-8")
    total = len(re.findall(r'^\s*-\s+\[[ x]\]', content, re.MULTILINE))
    completed = len(re.findall(r'^\s*-\s+\[x\]', content, re.MULTILINE))
    return completed == total, completed, total


def archive_change(root: Path, change_name: str, do_sync: bool = True) -> ArchiveResult:
    """Archive a completed change."""
    result = ArchiveResult(change_name=change_name)
    change_dir = root / "changes" / change_name
    archive_dir = root / "changes" / "archive"

    # Validate change exists
    if not change_dir.exists():
        result.errors.append(f"Change '{change_name}' not found")
        return result

    # Check tasks completion
    all_done, completed, total = check_tasks_complete(change_dir)
    if not all_done:
        result.warnings.append(f"Not all tasks complete ({completed}/{total}). Archiving anyway.")

    # Sync delta specs if requested
    if do_sync:
        delta_specs_dir = change_dir / "specs"
        if delta_specs_dir.exists() and any(delta_specs_dir.rglob("spec.md")):
            # Import and run sync
            script_dir = Path(__file__).parent
            sys.path.insert(0, str(script_dir))
            try:
                from sync import sync_change
                sync_result = sync_change(root, change_name)
                result.synced = True
                result.sync_actions = len(sync_result.actions)
                if sync_result.errors:
                    result.errors.extend(sync_result.errors)
                    return result
            except ImportError:
                result.warnings.append("Could not import sync module. Skipping sync.")

    # Move to archive
    today = date.today().isoformat()
    archive_name = f"{today}-{change_name}"
    target = archive_dir / archive_name

    # Ensure archive directory exists
    archive_dir.mkdir(parents=True, exist_ok=True)

    # Handle name collision
    if target.exists():
        counter = 1
        while target.exists():
            target = archive_dir / f"{archive_name}-{counter}"
            counter += 1

    try:
        shutil.move(str(change_dir), str(target))
        result.archive_path = str(target)
    except Exception as e:
        result.errors.append(f"Failed to move to archive: {e}")

    return result


def main():
    parser = argparse.ArgumentParser(description="OpenSpec archive")
    parser.add_argument("--root", required=True, help="Path to openspec/ directory")
    parser.add_argument("--change", required=True, help="Change to archive")
    parser.add_argument("--sync", action="store_true", default=True, help="Sync delta specs before archiving (default: true)")
    parser.add_argument("--no-sync", action="store_true", help="Skip sync")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    args = parser.parse_args()

    root = Path(args.root)
    do_sync = not args.no_sync

    result = archive_change(root, args.change, do_sync)

    if args.json:
        print(json.dumps(asdict(result), indent=2))
    else:
        if result.errors:
            for e in result.errors:
                print(f"ERROR: {e}", file=sys.stderr)
            sys.exit(1)

        if result.warnings:
            for w in result.warnings:
                print(f"WARNING: {w}")

        if result.synced:
            print(f"Synced {result.sync_actions} actions")

        if result.archive_path:
            print(f"Archived to: {result.archive_path}")
        else:
            print("Archive failed.")
            sys.exit(1)


if __name__ == "__main__":
    main()
