#!/usr/bin/env python3
"""OpenSpec list — Databricks port of `openspec list`.

Lists active changes and/or specs in the openspec directory.

Usage:
    python list_changes.py --root /Workspace/Users/.../openspec [--specs] [--json]
"""
import argparse
import json
import os
import re
import sys
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, asdict
from typing import List, Optional


@dataclass
class ChangeInfo:
    name: str
    completed_tasks: int
    total_tasks: int
    last_modified: str
    status: str  # no-tasks | complete | in-progress


@dataclass
class SpecInfo:
    spec_id: str
    requirement_count: int


def get_change_info(change_dir: Path) -> ChangeInfo:
    """Get info about an active change."""
    name = change_dir.name

    # Count tasks
    tasks_path = change_dir / "tasks.md"
    completed = 0
    total = 0
    if tasks_path.exists():
        content = tasks_path.read_text(encoding="utf-8")
        total = len(re.findall(r'^\s*-\s+\[[ x]\]', content, re.MULTILINE))
        completed = len(re.findall(r'^\s*-\s+\[x\]', content, re.MULTILINE))

    # Get last modified time
    latest = 0
    for f in change_dir.rglob("*"):
        if f.is_file():
            mtime = f.stat().st_mtime
            if mtime > latest:
                latest = mtime
    last_modified = datetime.fromtimestamp(latest).isoformat() if latest else "unknown"

    # Determine status
    if total == 0:
        status = "no-tasks"
    elif completed == total:
        status = "complete"
    else:
        status = "in-progress"

    return ChangeInfo(
        name=name,
        completed_tasks=completed,
        total_tasks=total,
        last_modified=last_modified,
        status=status,
    )


def get_spec_info(spec_path: Path, specs_root: Path) -> SpecInfo:
    """Get info about a main spec."""
    content = spec_path.read_text(encoding="utf-8")
    spec_id = str(spec_path.parent.relative_to(specs_root))
    req_count = len(re.findall(r'^###\s+Requirement:', content, re.MULTILINE))
    return SpecInfo(spec_id=spec_id, requirement_count=req_count)


def main():
    parser = argparse.ArgumentParser(description="OpenSpec list")
    parser.add_argument("--root", required=True, help="Path to openspec/ directory")
    parser.add_argument("--specs", action="store_true", help="List specs instead of changes")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    args = parser.parse_args()

    root = Path(args.root)

    if args.specs:
        specs_dir = root / "specs"
        specs = []
        if specs_dir.exists():
            for sf in sorted(specs_dir.rglob("spec.md")):
                specs.append(get_spec_info(sf, specs_dir))

        if args.json:
            print(json.dumps({"specs": [asdict(s) for s in specs], "root": str(root)}, indent=2))
        else:
            if not specs:
                print("No specs found.")
            else:
                print(f"{'Spec ID':<40s} {'Requirements':>12s}")
                print(f"{'---':<40s} {'---':>12s}")
                for s in specs:
                    print(f"{s.spec_id:<40s} {s.requirement_count:>12d}")
                print(f"\nTotal: {len(specs)} specs")
    else:
        changes_dir = root / "changes"
        changes = []
        if changes_dir.exists():
            for d in sorted(changes_dir.iterdir()):
                if d.is_dir() and d.name != "archive":
                    changes.append(get_change_info(d))

        if args.json:
            print(json.dumps({"changes": [asdict(c) for c in changes], "root": str(root)}, indent=2))
        else:
            if not changes:
                print("No active changes.")
            else:
                print(f"{'Change':<35s} {'Tasks':>10s} {'Status':>12s} {'Last Modified':>20s}")
                print(f"{'---':<35s} {'---':>10s} {'---':>12s} {'---':>20s}")
                for c in changes:
                    tasks_str = f"{c.completed_tasks}/{c.total_tasks}" if c.total_tasks > 0 else "-"
                    mod = c.last_modified[:19] if c.last_modified != "unknown" else "unknown"
                    print(f"{c.name:<35s} {tasks_str:>10s} {c.status:>12s} {mod:>20s}")
                print(f"\nTotal: {len(changes)} active changes")

    # Also show archive count
    archive_dir = root / "changes" / "archive"
    if archive_dir.exists():
        archived = len([d for d in archive_dir.iterdir() if d.is_dir()])
        if archived > 0 and not args.json:
            print(f"Archived: {archived} changes")


if __name__ == "__main__":
    main()
