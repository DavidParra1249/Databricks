#!/usr/bin/env python3
"""OpenSpec init — Databricks port of `openspec init`.

Initializes OpenSpec in a project directory. Creates the openspec/ folder
structure and config.yaml. Equivalent to running `openspec init` in a project.

Usage:
    python init.py --project /Workspace/Users/.../my-project [--schema spec-driven] [--context "..."] [--json]

The --project path is where openspec/ will be created. It must be an existing
directory (the project root).
"""
import argparse
import json
import os
import sys
from datetime import date
from pathlib import Path


# Resolve the package schemas directory (ships with the "install")
SCRIPTS_DIR = Path(__file__).parent
PACKAGE_DIR = SCRIPTS_DIR.parent  # .assistant/skills/openspec-sdd/
PACKAGE_SCHEMAS = PACKAGE_DIR / "schemas"


def init_project(project_path: Path, schema: str = "spec-driven", context: str = "") -> dict:
    """Initialize OpenSpec in a project directory."""
    result = {
        "project": str(project_path),
        "created": [],
        "errors": [],
        "already_exists": [],
    }

    openspec_dir = project_path / "openspec"

    # Check if already initialized
    if (openspec_dir / "config.yaml").exists():
        result["already_exists"].append(str(openspec_dir / "config.yaml"))
        result["errors"].append(
            f"OpenSpec already initialized in {project_path}. "
            f"config.yaml exists. Use --force to reinitialize."
        )
        return result

    # Create directory structure
    dirs_to_create = [
        openspec_dir / "specs",
        openspec_dir / "changes" / "archive",
    ]

    for d in dirs_to_create:
        d.mkdir(parents=True, exist_ok=True)
        result["created"].append(str(d.relative_to(project_path)))

    # Generate config.yaml
    project_name = project_path.name
    if not context:
        context = f"Project: {project_name}\n  Runtime: Databricks (Python, SQL, Spark)"

    config_content = f"""schema: {schema}

context: |
  {context}

rules:
  proposal:
    - Include rollback plan for breaking changes
    - Identify affected components
  specs:
    - Use GIVEN/WHEN/THEN format for scenarios
    - Reference existing patterns before inventing new ones
  design:
    - Prefer incremental changes over full rewrites
  tasks:
    - Group tasks by implementation slices
    - Include validation tasks for each slice

operations:
  apply:
    guidance:
      - Keep edits surgical and reversible
      - Update tests in the same slice where behavior changes
  archive:
    guidance:
      - Summarize what changed and what specs were updated
"""

    config_path = openspec_dir / "config.yaml"
    config_path.write_text(config_content, encoding="utf-8")
    result["created"].append(str(config_path.relative_to(project_path)))

    # Verify package schemas are accessible
    schema_dir = PACKAGE_SCHEMAS / schema
    if schema_dir.exists():
        result["schema_source"] = str(schema_dir)
    else:
        result["errors"].append(
            f"Schema '{schema}' not found at {PACKAGE_SCHEMAS}. "
            f"Available schemas: {[d.name for d in PACKAGE_SCHEMAS.iterdir() if d.is_dir()] if PACKAGE_SCHEMAS.exists() else 'none'}"
        )

    result["openspec_root"] = str(openspec_dir)
    return result


def main():
    parser = argparse.ArgumentParser(
        description="Initialize OpenSpec in a project directory"
    )
    parser.add_argument(
        "--project", required=True,
        help="Path to the project directory where openspec/ will be created"
    )
    parser.add_argument(
        "--schema", default="spec-driven",
        help="Schema to use (default: spec-driven)"
    )
    parser.add_argument(
        "--context", default="",
        help="Project context string for config.yaml"
    )
    parser.add_argument(
        "--force", action="store_true",
        help="Reinitialize even if already initialized"
    )
    parser.add_argument(
        "--json", action="store_true",
        help="Output as JSON"
    )
    args = parser.parse_args()

    project = Path(args.project)
    if not project.exists():
        print(f"ERROR: Project directory not found: {project}", file=sys.stderr)
        sys.exit(1)
    if not project.is_dir():
        print(f"ERROR: Not a directory: {project}", file=sys.stderr)
        sys.exit(1)

    # Handle --force
    if args.force:
        config = project / "openspec" / "config.yaml"
        if config.exists():
            config.unlink()

    result = init_project(project, args.schema, args.context)

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        if result["errors"]:
            for e in result["errors"]:
                print(f"ERROR: {e}", file=sys.stderr)
            sys.exit(1)

        print(f"Initialized OpenSpec in {result['project']}")
        print(f"Schema: {args.schema}")
        print(f"\nCreated:")
        for c in result["created"]:
            print(f"  {c}")
        if result.get("schema_source"):
            print(f"\nSchema source: {result['schema_source']}")
        print(f"\nNext: Edit openspec/config.yaml to add project-specific context.")
        print(f"Then use /opsx:propose to start your first change.")


if __name__ == "__main__":
    main()
