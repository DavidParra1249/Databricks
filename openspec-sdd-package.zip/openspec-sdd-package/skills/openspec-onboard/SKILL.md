---
name: openspec-onboard
description: Guided onboarding for OpenSpec - walk through a complete workflow cycle with narration and real workspace work.
metadata:
  author: openspec
  version: "1.0"
  ported-from: skills/openspec-onboard/SKILL.md
---

> **Databricks Genie Code port** of Fission-AI/OpenSpec.
> **Root resolution**: Find the nearest `openspec/` directory relative to the user's current project.
> **Scripts**: `.assistant/skills/openspec-sdd/scripts/` (pass `--root <project>/openspec` to all scripts).
> **Schemas**: `.assistant/skills/openspec-sdd/schemas/spec-driven/` (global, ships with the install).

Guide the user through their first complete OpenSpec workflow cycle. This is a teaching experience—you'll do real work in their workspace while explaining each step.

---

## Preflight

Before starting, check if OpenSpec is initialized in a project:

1. Resolve the project root: find the nearest `openspec/` directory relative to the user's current project.
2. If no `openspec/` found:
   > OpenSpec is not initialized in any project. Let me initialize it first.
   Run `python <SCRIPTS>/init.py --project <project-dir>` to initialize.
3. Set `ROOT` = `<project>/openspec`, `SCRIPTS` = `.assistant/skills/openspec-sdd/scripts`, `PACKAGE` = `.assistant/skills/openspec-sdd`.
4. Run `python <SCRIPTS>/validate.py --root <ROOT> --json` to confirm structure is valid.

---

## Phase 1: Welcome

Display:

```
## Welcome to OpenSpec!

I'll walk you through a complete change cycle—from idea to implementation—using a real task
in your workspace. Along the way, you'll learn the workflow by doing it.

**What we'll do:**
1. Pick a small, real task in your workspace
2. Explore the problem briefly
3. Create a change (the container for our work)
4. Build the artifacts: proposal → specs → design → tasks
5. Implement the tasks
6. Archive the completed change

**Time:** ~15-20 minutes

Let's start by finding something to work on.
```

---

## Phase 2: Task Selection

### Workspace Analysis

Scan the workspace project for improvement opportunities. Look for:

1. **TODO/FIXME comments** in notebooks and Python files
2. **Missing error handling** in existing code
3. **Functions without tests** or validation
4. **Configuration improvements** (hardcoded values, missing defaults)
5. **Missing documentation** in key notebooks or modules
6. **Data quality gaps** (missing validations, untested edge cases)

### Present Suggestions

From your analysis, present 3-4 specific suggestions:

```
## Task Suggestions

Based on scanning your workspace, here are some good starter tasks:

**1. [Most promising task]**
   Location: `path/to/file`
   Scope: ~1-2 files, ~20-30 lines
   Why it's good: [brief reason]

**2. [Second task]**
   ...

**3. Something else?**
   Tell me what you'd like to work on.

Which task interests you? (Pick a number or describe your own)
```

**If nothing found:** Ask what the user wants to build.

### Scope Guardrail

If the user picks something too large, gently suggest slicing smaller. Let the user override—this is a soft guardrail.

---

## Phase 3: Explore Demo

Once a task is selected, briefly demonstrate explore mode:

```
Before we create a change, let me quickly show you **explore mode**—it's how you think
through problems before committing to a direction.
```

Spend 1-2 minutes investigating the relevant code/files. Show what you find.

```
Explore mode (`/opsx:explore`) is for this kind of thinking—investigating before implementing.
You can use it anytime you need to think through a problem.

Now let's create a change to hold our work.
```

**PAUSE** - Wait for user acknowledgment before proceeding.

---

## Phase 4: Create the Change

**EXPLAIN:**
```
## Creating a Change

A "change" in OpenSpec is a container for all the thinking and planning around a piece
of work. It holds your artifacts—proposal, specs, design, tasks.
```

**DO:** Create the change directory:
- Create `<ROOT>/changes/<derived-name>/`
- Create `.openspec.yaml` with `schema: spec-driven` and `created: YYYY-MM-DD`
- Run `python <SCRIPTS>/status.py --root <ROOT> --change <name> --json` to confirm

**SHOW:** The folder structure and explain each artifact's purpose.

---

## Phase 5: Proposal

**EXPLAIN:** The proposal captures **why** we're making this change.

**DO:** Draft the proposal using the template from `<PACKAGE>/schemas/spec-driven/templates/proposal.md`.

**PAUSE** - Wait for user approval/feedback before saving.

---

## Phase 6: Specs

**EXPLAIN:** Specs define **what** we're building in precise, testable terms (GIVEN/WHEN/THEN).

**DO:** Draft the spec using the template from `<PACKAGE>/schemas/spec-driven/templates/spec.md`.

---

## Phase 7: Design

**EXPLAIN:** The design captures **how** we'll build it—technical decisions, tradeoffs, approach.

**DO:** Draft design.md using the template from `<PACKAGE>/schemas/spec-driven/templates/design.md`.

---

## Phase 8: Tasks

**EXPLAIN:** Break the work into implementation tasks—checkboxes that drive the apply phase.

**DO:** Generate tasks using the template from `<PACKAGE>/schemas/spec-driven/templates/tasks.md`.

**PAUSE** - Wait for user to confirm they're ready to implement.

---

## Phase 9: Apply (Implementation)

**EXPLAIN:** Now we implement each task, checking them off as we go.

**DO:** For each task:
1. Announce: "Working on task N: [description]"
2. Implement the change in the workspace
3. Reference specs/design naturally
4. Mark complete in tasks.md: `- [ ]` → `- [x]`
5. Brief status: "✓ Task N complete"

After all tasks: show implementation complete summary.

---

## Phase 10: Archive

**EXPLAIN:** When a change is complete, we archive it. Archived changes become your project's decision history.

**DO:** Archive the change:
```sh
python <SCRIPTS>/archive.py --root <ROOT> --change <name>
```

---

## Phase 11: Recap & Next Steps

```
## Congratulations!

You just completed a full OpenSpec cycle:

1. **Explore** - Thought through the problem
2. **New** - Created a change container
3. **Proposal** - Captured WHY
4. **Specs** - Defined WHAT in detail
5. **Design** - Decided HOW
6. **Tasks** - Broke it into steps
7. **Apply** - Implemented the work
8. **Archive** - Preserved the record

This same rhythm works for any size change.

## Command Reference

| Command | What it does |
|---|---|
| `/opsx:propose` | Create a change and generate all artifacts |
| `/opsx:explore` | Think through problems before/during work |
| `/opsx:apply` | Implement tasks from a change |
| `/opsx:archive` | Archive a completed change |
| `/opsx:new` | Start a new change, step through artifacts one at a time |
| `/opsx:continue` | Continue working on an existing change |
| `/opsx:ff` | Fast-forward: create all artifacts at once |
| `/opsx:verify` | Verify implementation matches artifacts |
| `/opsx:sync` | Merge delta specs into main specs |
| `/opsx:update` | Revise planning artifacts |
| `/opsx:bulk-archive` | Archive multiple changes at once |
| `/opsx:onboard` | This guided tutorial |

Try `/opsx:propose` to start your next change!
```

---

## Graceful Exit Handling

### User wants to stop mid-way

Save progress and explain how to resume:
- `/opsx:continue <name>` to resume artifact creation
- `/opsx:apply` to jump to implementation (if tasks exist)

### User just wants command reference

Show the command table from Phase 11 and exit gracefully.

---

## Guardrails

- **Follow the EXPLAIN → DO → SHOW → PAUSE pattern** at key transitions
- **Keep narration light** during implementation—teach without lecturing
- **Don't skip phases** even if the change is small—the goal is teaching the workflow
- **Pause for acknowledgment** at marked points, but don't over-pause
- **Handle exits gracefully**—never pressure the user to continue
- **Use real workspace tasks**—don't simulate or use fake examples
- **Adjust scope gently**—guide toward smaller tasks but respect user choice
