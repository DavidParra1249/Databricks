---
name: openspec-continue-change
description: Continue working on an OpenSpec change by creating the next artifact. Use when the user wants to progress their change, create the next artifact, or continue their workflow.
metadata:
  author: openspec
  version: "1.0"
  ported-from: skills/openspec-continue-change/SKILL.md
---

> **Databricks Genie Code port** of Fission-AI/OpenSpec.
> **Root resolution**: Find the nearest `openspec/` directory relative to the user's current project.
> **Scripts**: `.assistant/skills/openspec-sdd/scripts/` (pass `--root <project>/openspec` to all scripts).
> **Schemas**: `.assistant/skills/openspec-sdd/schemas/spec-driven/` (global, ships with the install).

Continue working on a change by creating the next artifact.

**Input**: Optionally specify a change name. If omitted, check if it can be inferred from conversation context. If vague or ambiguous you MUST prompt for available changes.

**Steps**

1. **Resolve the project root**

   Find the nearest `openspec/` directory relative to the user's current project.
   Set `ROOT` = `<project>/openspec`, `SCRIPTS` = `.assistant/skills/openspec-sdd/scripts`, `PACKAGE` = `.assistant/skills/openspec-sdd`.

2. **Select the change**

   If a name is provided, use it. Otherwise:
   - Infer from conversation context if the user mentioned a change
   - Auto-select if only one active change exists
   - If ambiguous, run:
     ```sh
     python <SCRIPTS>/list_changes.py --root <ROOT> --json
     ```
     Present the top 3-4 most recently modified changes as options, showing:
     - Change name
     - Schema (from `.openspec.yaml`)
     - Status (e.g., "0/5 tasks", "complete", "no tasks")
     - How recently it was modified

   Mark the most recently modified change as "(Recommended)".
   Always announce: "Using change: <name>" and how to override.

3. **Check current status**

   ```sh
   python <SCRIPTS>/status.py --root <ROOT> --change <name> --json
   ```

   Parse the JSON to understand current state. The response includes:
   - `schemaName`: The workflow schema being used
   - `artifacts`: Array of artifacts with their status ("done", "skipped", "ready", "blocked")
   - `isPlanningComplete`: Boolean indicating if all planning artifacts are complete

4. **Act based on status**:

   ---

   **If all planning artifacts are complete (`isPlanningComplete: true`)**:
   - Congratulate the user
   - Show final status including the schema used
   - Suggest: "Planning is complete! You can now implement this change with `/opsx:apply`. Once done, archive it with `/opsx:archive`."
   - STOP

   ---

   **If artifacts are ready to create** (status shows artifacts with `status: "ready"`):
   - Pick the FIRST artifact with `status: "ready"` from the status output
   - Get its instructions from `<PACKAGE>/schemas/spec-driven/schema.yaml` (the artifact's `instruction` and `template`)
   - Read the template from `<PACKAGE>/schemas/spec-driven/templates/<artifact>.md`
   - **Create the artifact file**:
     - Read any completed dependency files for context - always re-read from disk
     - Use `template` as the structure - fill in its sections
     - Apply `context` (from config.yaml) and `rules` as constraints when writing - but do NOT copy them into the file
     - Write to the correct path in the change directory
   - Show what was created and what's now unlocked
   - STOP after creating ONE artifact

   ---

   **If no artifacts are ready (all blocked)**:
   - Show status and suggest checking for issues

5. **After creating an artifact, show progress**

   ```sh
   python <SCRIPTS>/status.py --root <ROOT> --change <name>
   ```

**Output**

After each invocation, show:
- Which artifact was created
- Schema workflow being used
- Current progress (N/M complete)
- What artifacts are now unlocked
- Prompt: "Want to continue? Just ask me to continue or tell me what to do next."

**Artifact Creation Guidelines**

The artifact types and their purpose depend on the schema. The `instruction` field from schema.yaml is the authoritative guidance for each artifact - follow it even when the artifact has a familiar name (proposal.md, tasks.md, etc.).

**Guardrails**
- Create ONE artifact per invocation
- Always read dependency artifacts before creating a new one - re-read from disk, not from conversation memory
- Never skip artifacts or create out of order
- If context is unclear, ask the user before creating
- Verify the artifact file exists after writing before marking progress
- Use the schema's artifact sequence, don't assume specific artifact names
- **IMPORTANT**: `context` and `rules` are constraints for YOU, not content for the file
  - Do NOT copy `<context>`, `<rules>`, `<project_context>` blocks into the artifact
  - These guide what you write, but should never appear in the output
