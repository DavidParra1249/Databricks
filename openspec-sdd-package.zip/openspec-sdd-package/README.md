# OpenSpec SDD for Databricks Genie Code

Databricks port of [Fission-AI/OpenSpec](https://github.com/Fission-AI/OpenSpec) — Spec-Driven Development for AI coding assistants.

## Quick Start

### 1. Install (one time per user)

Run in a notebook cell or terminal:

```sh
python /Workspace/Shared/openspec-sdd-package/install.py
```

This copies 12 command skills + engine to your `.assistant/skills/`.

### 2. Initialize a project

```sh
python ~/.assistant/skills/openspec-sdd/scripts/init.py --project /Workspace/Users/<you>/my-project
```

Creates `openspec/` inside your project with config.yaml, specs/, and changes/.

### 3. Use in Genie Code chat

Type any `/opsx:` command:

| Command | What it does |
|---|---|
| `/opsx:propose <name>` | Create a change with all planning artifacts |
| `/opsx:explore` | Think through ideas before committing |
| `/opsx:apply` | Implement tasks from a change |
| `/opsx:new <name>` | Start a change step-by-step |
| `/opsx:continue` | Create the next artifact |
| `/opsx:ff <name>` | Fast-forward: all artifacts at once |
| `/opsx:update` | Revise planning artifacts |
| `/opsx:verify` | Verify implementation matches specs |
| `/opsx:sync` | Merge delta specs into main specs |
| `/opsx:archive` | Archive a completed change |
| `/opsx:bulk-archive` | Archive multiple changes at once |
| `/opsx:onboard` | Guided tutorial through the workflow |

## Management

```sh
# Check installation status
python /Workspace/Shared/openspec-sdd-package/install.py --status

# Update to latest version
python /Workspace/Shared/openspec-sdd-package/install.py --force

# Uninstall (keeps project data)
python /Workspace/Shared/openspec-sdd-package/install.py --uninstall
```

## Architecture

```
Global (per user, installed once):          Per project (created by init.py):
~/.assistant/skills/                        my-project/
├── openspec-sdd/                           └── openspec/
│   ├── SKILL.md (index/router)                 ├── config.yaml
│   ├── schemas/spec-driven/                    ├── specs/
│   │   ├── schema.yaml                         └── changes/
│   │   └── templates/*.md
│   └── scripts/*.py (engine)
├── openspec-propose/SKILL.md
├── openspec-explore/SKILL.md
├── openspec-apply/SKILL.md
├── ... (12 command skills total)
```

## Philosophy

```
fluid not rigid         — no phase gates, work on what makes sense
iterative not waterfall — learn as you build, refine as you go
easy not complex        — lightweight setup, minimal ceremony
brownfield-first        — works with existing codebases, not just greenfield
```

## Credits

Ported from [Fission-AI/OpenSpec](https://github.com/Fission-AI/OpenSpec) (MIT License).
