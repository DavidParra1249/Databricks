#!/usr/bin/env python3
"""OpenSpec SDD Installer for Databricks Workspace.

Installs the OpenSpec Spec-Driven Development skills into your Genie Code
assistant. This is the Databricks equivalent of `npm install -g @fission-ai/openspec`.

Usage (run in a Databricks notebook cell or terminal):
    %sh python /Workspace/Shared/openspec-sdd-package/install.py

Options:
    --dry-run     Show what would be installed without making changes
    --force       Overwrite existing skills (default: skip if exists)
    --uninstall   Remove all OpenSpec skills from your .assistant/skills/
    --status      Show installation status

After installing, initialize OpenSpec in any project:
    %sh python ~/.assistant/skills/openspec-sdd/scripts/init.py --project /Workspace/Users/<you>/my-project

Then use /opsx:propose, /opsx:explore, /opsx:apply, etc. in Genie Code chat.

Ported from: https://github.com/Fission-AI/OpenSpec
"""
import argparse
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path


# ── Constants ──────────────────────────────────────────────────────────────

PACKAGE_DIR = Path(__file__).parent / "skills"
VERSION = "1.0.0"

SKILL_DIRS = [
    "openspec-sdd",               # Engine: scripts, schemas, index
    "openspec-propose",           # /opsx:propose
    "openspec-explore",           # /opsx:explore
    "openspec-apply",             # /opsx:apply
    "openspec-update",            # /opsx:update
    "openspec-verify",            # /opsx:verify
    "openspec-sync",              # /opsx:sync
    "openspec-archive",           # /opsx:archive
    "openspec-new-change",        # /opsx:new
    "openspec-continue-change",   # /opsx:continue
    "openspec-ff-change",         # /opsx:ff
    "openspec-onboard",           # /opsx:onboard
    "openspec-bulk-archive-change",  # /opsx:bulk-archive
]


# ── Helpers ────────────────────────────────────────────────────────────────

def detect_user_home() -> Path:
    """Detect the current user's Databricks workspace home directory."""
    # Method 1: Environment variable
    user = os.environ.get("DB_USER") or os.environ.get("DATABRICKS_USER")
    if user:
        return Path(f"/Workspace/Users/{user}")

    # Method 2: Scan /Workspace/Users/ for writable directories
    users_dir = Path("/Workspace/Users")
    if users_dir.exists():
        for d in users_dir.iterdir():
            if d.is_dir() and not d.name.startswith("."):
                # Check if we can write to this directory
                test_file = d / ".assistant" / ".install_test"
                try:
                    test_file.parent.mkdir(parents=True, exist_ok=True)
                    test_file.write_text("test")
                    test_file.unlink()
                    return d
                except (PermissionError, OSError):
                    continue

    # Method 3: Check CWD
    cwd = Path.cwd()
    if "/Users/" in str(cwd):
        parts = str(cwd).split("/Users/")
        if len(parts) > 1:
            user_part = parts[1].split("/")[0]
            return Path(f"/Workspace/Users/{user_part}")

    return None


def get_skills_dir(home: Path) -> Path:
    """Get the .assistant/skills/ directory for a user."""
    return home / ".assistant" / "skills"


def count_files(path: Path) -> tuple:
    """Count files and total chars in a directory."""
    files = list(path.rglob("*"))
    file_count = sum(1 for f in files if f.is_file())
    char_count = sum(len(f.read_text(encoding="utf-8")) for f in files if f.is_file())
    return file_count, char_count


# ── Actions ────────────────────────────────────────────────────────────────

def install(home: Path, force: bool = False, dry_run: bool = False):
    """Install OpenSpec skills to the user's .assistant/skills/."""
    target = get_skills_dir(home)

    print(f"OpenSpec SDD Installer v{VERSION}")
    print(f"Source:  {PACKAGE_DIR}")
    print(f"Target:  {target}")
    print(f"Mode:    {'DRY RUN' if dry_run else 'INSTALL'} {'(force)' if force else ''}")
    print()

    if not PACKAGE_DIR.exists():
        print(f"ERROR: Package not found at {PACKAGE_DIR}", file=sys.stderr)
        sys.exit(1)

    installed = []
    skipped = []
    updated = []

    for skill_name in SKILL_DIRS:
        src = PACKAGE_DIR / skill_name
        dst = target / skill_name

        if not src.exists():
            print(f"  WARN: {skill_name} not found in package, skipping")
            continue

        src_files, src_chars = count_files(src)

        if dst.exists():
            if force:
                if not dry_run:
                    shutil.rmtree(str(dst))
                    shutil.copytree(str(src), str(dst))
                updated.append((skill_name, src_files, src_chars))
                print(f"  ↻ {skill_name:40s}  {src_files:>2d} files  {src_chars:>6d} chars  (updated)")
            else:
                dst_files, dst_chars = count_files(dst)
                skipped.append((skill_name, dst_files, dst_chars))
                print(f"  · {skill_name:40s}  {dst_files:>2d} files  {dst_chars:>6d} chars  (exists, skip)")
        else:
            if not dry_run:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copytree(str(src), str(dst))
            installed.append((skill_name, src_files, src_chars))
            print(f"  ✓ {skill_name:40s}  {src_files:>2d} files  {src_chars:>6d} chars  (installed)")

    # Summary
    print()
    print(f"Summary:")
    print(f"  Installed: {len(installed)}")
    print(f"  Updated:   {len(updated)}")
    print(f"  Skipped:   {len(skipped)} (use --force to overwrite)")
    total = len(installed) + len(updated) + len(skipped)
    print(f"  Total:     {total}/{len(SKILL_DIRS)} skills")

    if installed or updated:
        print(f"\n{'[DRY RUN] Would be ready' if dry_run else 'Ready'}! Available commands:")
        print(f"  /opsx:propose    /opsx:explore    /opsx:apply")
        print(f"  /opsx:new        /opsx:continue   /opsx:ff")
        print(f"  /opsx:update     /opsx:verify     /opsx:sync")
        print(f"  /opsx:archive    /opsx:bulk-archive  /opsx:onboard")
        print(f"\nNext: Initialize OpenSpec in a project:")
        print(f"  python {target}/openspec-sdd/scripts/init.py --project <your-project-path>")


def uninstall(home: Path, dry_run: bool = False):
    """Remove all OpenSpec skills from the user's .assistant/skills/."""
    target = get_skills_dir(home)

    print(f"OpenSpec SDD Uninstaller v{VERSION}")
    print(f"Target: {target}")
    print(f"Mode:   {'DRY RUN' if dry_run else 'UNINSTALL'}")
    print()

    removed = []
    not_found = []

    for skill_name in SKILL_DIRS:
        dst = target / skill_name
        if dst.exists():
            files, chars = count_files(dst)
            if not dry_run:
                shutil.rmtree(str(dst))
            removed.append((skill_name, files, chars))
            print(f"  ✗ {skill_name:40s}  {files:>2d} files  {chars:>6d} chars  (removed)")
        else:
            not_found.append(skill_name)

    print(f"\n{'[DRY RUN] Would remove' if dry_run else 'Removed'}: {len(removed)} skill directories")
    if not_found:
        print(f"Not found: {len(not_found)} (already uninstalled)")

    print(f"\nNote: Project data (openspec/ folders inside projects) is NOT removed.")
    print(f"Your specs, changes, and archives are preserved.")


def status(home: Path):
    """Show installation status."""
    target = get_skills_dir(home)

    print(f"OpenSpec SDD Status v{VERSION}")
    print(f"Location: {target}")
    print()

    installed = []
    missing = []

    for skill_name in SKILL_DIRS:
        dst = target / skill_name
        if dst.exists():
            files, chars = count_files(dst)
            installed.append((skill_name, files, chars))
            print(f"  ✓ {skill_name:40s}  {files:>2d} files  {chars:>6d} chars")
        else:
            missing.append(skill_name)
            print(f"  ✗ {skill_name:40s}  NOT INSTALLED")

    print(f"\nInstalled: {len(installed)}/{len(SKILL_DIRS)} skills")
    if missing:
        print(f"Missing:   {', '.join(missing)}")
        print(f"\nRun: python {__file__} --force")
    else:
        print("All skills installed.")


# ── Main ───────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Install OpenSpec SDD skills for Databricks Genie Code",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python install.py                  # Install skills
  python install.py --dry-run        # Preview what would be installed
  python install.py --force          # Overwrite existing skills (update)
  python install.py --uninstall      # Remove all OpenSpec skills
  python install.py --status         # Check installation status

After installing:
  python ~/.assistant/skills/openspec-sdd/scripts/init.py --project <path>

Then in Genie Code chat:
  /opsx:propose add-dark-mode
"""
    )
    parser.add_argument("--dry-run", action="store_true", help="Preview without making changes")
    parser.add_argument("--force", action="store_true", help="Overwrite existing skills")
    parser.add_argument("--uninstall", action="store_true", help="Remove all OpenSpec skills")
    parser.add_argument("--status", action="store_true", help="Show installation status")
    args = parser.parse_args()

    # Detect user home
    home = detect_user_home()
    if not home:
        print("ERROR: Could not detect your workspace home directory.", file=sys.stderr)
        print("Make sure you're running this from a Databricks notebook or terminal.", file=sys.stderr)
        sys.exit(1)

    print(f"User home: {home}\n")

    if args.status:
        status(home)
    elif args.uninstall:
        uninstall(home, dry_run=args.dry_run)
    else:
        install(home, force=args.force, dry_run=args.dry_run)


if __name__ == "__main__":
    main()
